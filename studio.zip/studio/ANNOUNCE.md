### New version 0.3.0 with support for the latest firmware

Last year, the Lunii firmware has seen a complete overhaul, affecting deeply the format and transfer of story packs.
Thanks to the community and after a few months of beta testing, STUdio is now ready to support this new firmware!

-----

### La nouvelle version 0.3.0 supporte le nouveau firmware

L'année dernière, le firmware Lunii (le "micrologiciel" embarqué dans l'appareil) a connu des évolutions majeures, qui
ont impacté en particulier le format et le transfert des packs d'histoires. Grâce à la communauté, et après quelques
mois de bêta-test, STUdio supporte maintenant ce nouveau firmware !

mettre ici le fichier .ri du pack.
Lancer le java "Simple" dans le projet Eclipse en tant que java Application, le fichier bt sera généré